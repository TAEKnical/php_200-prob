<?php
  phpinfo();
 ?>
