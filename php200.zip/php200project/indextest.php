<!doctype html>
<html>
<head>
<link rel="stylesheet" href="167-layoutCSS.php" />
</head>
<body>
    <div id="wrap">
        <div id="header"></div>
        <section id="leftArea"></section>
        <aside id="rightArea"></aside>
        <div id="footer"></div>
    </div>
</body>
</html>
