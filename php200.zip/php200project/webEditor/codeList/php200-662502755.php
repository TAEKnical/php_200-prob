<?php
$plus=3+1;
echo $plus;
?>