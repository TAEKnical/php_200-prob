<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>INPUT태그 파일업로드</title>
  </head>
  <body>
    <form name=" " action=" " method=" " enctype="multipart/form-data">
      파일 : <input type="file" name="attachedFile"/>
    </form>
  </body>
</html>
