<?php
//배열의 값 개수 확인하기
  $arr = range(1,20,2);
  echo "arr 배열의 앨리먼트 개수는 : ".count($arr);
 ?>
