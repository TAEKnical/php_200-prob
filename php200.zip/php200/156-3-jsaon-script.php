<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <script>
      data={student:[{name:'mima',score:{math:4,english:5,science:6}},{name:'haro',score:{math:7,english:8,science:9}}]};
      console.log(data.student[0].score.english);
    </script>
  </head>
  <body>
  </body>
</html>
