<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <script>
      data = {userID:'mickey'};
      console.log(data.userID);//console 함수의 결과는 개발자도구의 콘솔탭에서 확인가능
    </script>
  </head>
  <body>
  </body>
</html>
