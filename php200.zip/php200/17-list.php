<?php
  $fruit = array();
  $fruit = ['grape','apple','banana'];

  list($first, $second, $third) = $fruit;
  // list($first,$second)=$fruit; //정상작동함
  echo $second;
 ?>
