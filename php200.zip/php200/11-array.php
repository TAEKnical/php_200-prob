<?php
//배열 선언
$earth = array();

//earth의 0인덱스에 'korea' 대입
$earth[0] = 'korea';

//earth 배열의 0 인덱스 출력
echo "earth 배열의 0 인덱스는 ".$earth[0];
 ?>
