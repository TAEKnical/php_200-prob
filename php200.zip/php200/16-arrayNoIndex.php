<?php
//배열에 인덱스를 지정하지 않고 값 입력하기
 $fruit = array();
 $fruit = ['banana', 'Water melon', 'grape'];

 echo $fruit[0]; //banana
 echo "<br>";
 echo $fruit[2]; //grape
 ?>
