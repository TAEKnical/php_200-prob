<?php
//배열 선언
$earth = array();

//earth의 nation 인덱스에 'korea' 대입
$earth['nation']='korea';

//earth 배열의 nation 인덱스 출력
echo "earth 배열의 nation 인덱스는 ".$earth['nation'];
 ?>
