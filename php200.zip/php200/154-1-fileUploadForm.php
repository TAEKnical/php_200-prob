<!DOCTYPE html>
<html>
<head>
<title>파일업로드 폼</title>
</head>
<body>
<form name="fileUpload" method="post" action="./154-3-imgUpload.php"
      enctype="multipart/form-data">
    <input type="file" name="imgFile" />
    <input type="submit" value="업로드"/>
</form>
</body>
</html>
