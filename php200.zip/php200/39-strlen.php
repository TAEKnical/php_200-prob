<?php
//문자열 길이
  $str = "beanscent";
  echo " 문자열 수 : ".strlen($str);

  $str = "b e a n s c e n t";
  echo " 문자열 수 : ".strlen($str);
//공백도 하나의 문자로 인식

 ?>
