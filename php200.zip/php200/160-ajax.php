<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <script>
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if (this.readyState == 4&&this.status == 200){ //this.readyState가 4이면 연결상태에 이상이 없음, this.status는 서버의 처리 결과에 대한 값을 반환하며 200이면 정상
          console.log(this.responesText);//서버가 반환한 값을 표시
          data = JSON.parse(this.responseText);//그 값은 현재 문자열에 불과하므로 JOSN형태의 데이터로 만들기 위함
          console.log(data.student);
        }
      };
      xhttp.open("POST","http://localhost/php200/157-1.json",true);
      xhttp.send();
    </script>
  </head>
  <body>

  </body>
</html>
