<?php
  class hello{
    public static function output($word){
      echo $word;
    }
  }

  hello::output("안녕이라고 말해봐");
 ?>
