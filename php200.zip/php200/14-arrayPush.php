<?php
//배열에 값 추가하기
  $fruit = array();
  $num = array();
  array_push($fruit, 'apple', 'banana', 'grape');
  array_push($num,1,2,3);

  echo $fruit[0]."<br>";
  echo $fruit[1]."<br>";
  echo $fruit[2]."<br>";
  echo "<br><br>";
  echo $num[0]."<br>";
  echo $num[1]."<br>";
  echo $num[2]."<br>";

 ?>
