<?php
  print "안녕하세요";
  print "<br>";
  print "반갑습니다.";
  print "<br>";
  print 1234;
  print "<br>";
  print "4월 4일에 태어났습니다.";
 ?>
