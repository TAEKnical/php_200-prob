<!DOCTYPE html>
<html lang="" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>INPUT 태그</title>
  </head>
  <body>
    <form naem="폼 태그 이름" action="데이터 보낼 주소" method="데이터 전송 방식">
      <input type="email" name="userEmail" placeholder="이메일 입력"/>
      <input type="submit" value="전송"/>
    </form>
  </body>
</html>
