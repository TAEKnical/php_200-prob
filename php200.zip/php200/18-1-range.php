<?php
  $num = range(1,10);

  echo "<pre>";
  var_dump($num);
 ?>
