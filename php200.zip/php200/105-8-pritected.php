<?php
  class a{
    protected function hello(){
      echo "say hello~";
  }

  $a = new a();
  $a -> hello();
 ?>
