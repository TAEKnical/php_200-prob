<?php
//타임스태프값을 감소시켜 쿠키 값을 없앤다.
setCookie("memberID","everdevel",time()-100,"/");

 ?>
