<?php
  echo json_encode(array('result'=>'success','data'=>array('english'=>100,'math'=>95)));
?>
