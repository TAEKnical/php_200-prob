<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TEXTAREA 태그 입력폼</title>
  </head>
  <body>
    <form name="textsave" action="./152-2-textSave.php" method="post">
      <textarea name="text" rows="8" cols="80"></textarea>
      <input type="submit" value="저장">
    </form>
  </body>
</html>
