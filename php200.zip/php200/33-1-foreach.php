<?php
//초기값,조건,증감식 없이도 반복문을 쓸 수 있다. python에서의 for문과 같은 동작법
  $memberList=['미우','유나','민후','해윤'];

  foreach($memberList as $ml){
    echo $ml;
    echo '<br>';
  }
 ?>
