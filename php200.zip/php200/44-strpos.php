<?php
//문자열 속에서 특정 문자의 인덱스 찾기
$str = "web development";
$findStr = 'opm';
$pos = strpos($str,$findStr);
echo "문자열 {$str}의 위치는 {$pos}";
 ?>
