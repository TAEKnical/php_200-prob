<?php
///age=25&hobby=singing
  echo "age의 값 : ".$_GET['age'];
  echo "<br>";
  echo "hobby의 값 : ".$_GET['hobby'];
 ?>
