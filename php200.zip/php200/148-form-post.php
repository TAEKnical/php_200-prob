<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>POST 방식 데이터 입력폼</title>
  </head>
  <body>
    <form name="test" action="./147-post.php" method="post">
      나이 : <input type="text" name="age" />
      취미 : <input type="text" name="hobby" />
      <input type="submit" value="전송"/>
    </form>
  </body>
</html>
