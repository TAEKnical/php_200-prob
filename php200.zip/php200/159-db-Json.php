<?php
  include $_SERVER["DOCUMENT_ROOT"].'/php200/108-2-connectDB.php';

  $sql = "SELECT * FROM myMember";
  $res = $dbConnect->query($sql);

  $dataCount=$res->num_rows;
  $memberList=array();

  for($i=0;$i<$dataCount;$i++){
    $memberInfo=$res->fetch_array(MYSQLI_ASSOC);
    array_push($memberList,$memberInfo);//memberInfo에서 가져온 데이터를 memberList에 추가한다
  }
  echo json_encode(array('data'=>$memberList));
?>
